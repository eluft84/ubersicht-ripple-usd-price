# Übersicht Widget - XRP/USD price

![Screenshot](https://github.com/eluft84/ubersicht-ripple-usd-price/blob/master/screenshot.png)

Based on [Daniel Spillere Andrade BTC widget](https://github.com/felixhageloh/uebersicht-widgets/tree/master/btc). 
